import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/contexts/ThemeContext";
import { LanguageProvider } from "@/contexts/LanguageContext";
import { useSEO, useGermanSEO } from "@/hooks/useSEO";
import { Layout } from "@/components/Layout";
import { useAuth } from "@/hooks/useAuth";

import NotFound from "@/pages/not-found";
import Landing from "@/pages/Landing";
import Login from "@/pages/Login";
import Register from "@/pages/Register";
import Home from "@/pages/HomeNew";
import ChatMainNew from "@/pages/ChatMainNew";
import Profile from "@/pages/Profile";
import ProfileEditUnified from "@/pages/ProfileEditUnified";
import EscortProfile from "@/pages/EscortProfile";
import Explore from "@/pages/Explore";
import Settings from "@/pages/Settings";
import Subscribe from "@/pages/Subscribe";
import Premium from "@/pages/Premium";
import PremiumSuccess from "@/pages/PremiumSuccess";
import PremiumDeclined from "@/pages/PremiumDeclined";
import Terms from "@/pages/Terms";
import Privacy from "@/pages/Privacy";
import Legal from "@/pages/Legal";
import Admin from "@/pages/Admin";
import UserTypeSelection from "@/pages/UserTypeSelection";
import ForgotPassword from "@/pages/ForgotPassword";
import ResetPassword from "@/pages/ResetPassword";
import VerifyEmail from "@/pages/VerifyEmail";
import PrivateAlbums from "@/pages/PrivateAlbums";

function Router() {
  const { isAuthenticated, isLoading } = useAuth();
  
  // Apply SEO optimizations
  useSEO();
  useGermanSEO();

  // Don't show loading for unauthenticated users - just show the app
  if (isLoading && isAuthenticated) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-[#FF007F] border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <Switch>
      {/* Authentication routes - always accessible */}
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route path="/select-type" component={UserTypeSelection} />
      <Route path="/forgot-password" component={ForgotPassword} />
      <Route path="/reset-password" component={ResetPassword} />
      <Route path="/verify-email" component={VerifyEmail} />
      
      {/* Public routes - always accessible */}
      <Route path="/" component={Home} />
      <Route path="/landing" component={Landing} />
      
      {/* Protected routes - require authentication */}
      {isAuthenticated && (
        <>
          <Route path="/chat" component={ChatMainNew} />
          <Route path="/my-profile" component={Profile} />
          <Route path="/my-profile/edit" component={ProfileEditUnified} />
          <Route path="/settings" component={Settings} />
          {/* Albums only for trans escorts */}
          <Route path="/albums" component={PrivateAlbums} />
          {/* Premium subscription only for trans escorts */}
          <Route path="/subscribe" component={Subscribe} />
          <Route path="/premium" component={Premium} />
        </>
      )}
      
      {/* Admin route - accessible for all authenticated users (protection handled in component) */}
      <Route path="/admin" component={Admin} />
      
      {/* Premium success/failure routes - accessible without auth for payment callbacks */}
      <Route path="/premium-success" component={PremiumSuccess} />
      <Route path="/premium-declined" component={PremiumDeclined} />
      
      {/* Legal pages - accessible without auth */}
      <Route path="/terms" component={Terms} />
      <Route path="/privacy" component={Privacy} />
      <Route path="/legal" component={Legal} />
      
      {/* Profile viewing - accessible but may require auth for contact */}
      <Route path="/profile/:userId" component={EscortProfile} />
      <Route path="/profile" component={EscortProfile} />
      <Route path="/explore" component={Explore} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <LanguageProvider>
        <ThemeProvider>
          <TooltipProvider>
            <Layout>
              <Router />
            </Layout>
            <Toaster />
          </TooltipProvider>
        </ThemeProvider>
      </LanguageProvider>
    </QueryClientProvider>
  );
}

export default App;
